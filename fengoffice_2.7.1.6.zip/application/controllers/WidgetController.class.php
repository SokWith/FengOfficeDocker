<?php
class WidgetController extends  ApplicationController {
	
}