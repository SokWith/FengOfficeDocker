<?php header('Content-type: text/javascript; charset=UTF-8', true); ?>
<?php echo $content_for_layout ?>