<?php

  /**
  * EmailType class
  * 
  * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
  */
  class EmailType extends BaseEmailType {
  
        
  } // EmailType 

?>