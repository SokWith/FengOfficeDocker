<?php

/**
 *  TemplateParameter class
 *
 * @author Pablo Kamil
 */
class TemplateParameter extends BaseTemplateParameter {

	/**
    * Construct the object
    *
    * @param void
    * @return null
    */
    function __construct() {
      parent::__construct();
    } // __construct
    

} // TemplateParameter

?>