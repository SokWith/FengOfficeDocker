<?php

/**
 * ContactMemberPermission class
 *
 * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
 */
class ContactMemberPermission extends BaseContactMemberPermission {
	

} // ContactMemberPermission

?>