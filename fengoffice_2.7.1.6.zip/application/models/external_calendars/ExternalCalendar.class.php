<?php
/**
 * ExternalCalendar
 * Generado el 22/2/2012
 * 
 */
class ExternalCalendar extends BaseExternalCalendar {
    
}
?>