<?php

  /**
  * EventInvitation class
  * Generated on Mon, 13 Oct 2008
  *
  * @author Alvaro Torterola <alvaro.torterola@fengoffice.com>
  */
  class EventInvitation extends BaseEventInvitation {
  
  } // EventInvitation 

?>