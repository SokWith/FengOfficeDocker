<?php

  /**
  * FileType class
  * Generated on Tue, 28 Mar 2006 00:25:04 +0200 by DataObject generation tool
  *
  * @author Ilija Studen <ilija.studen@gmail.com>
  */
  class FileType extends BaseFileType {
  
  } // FileType 

?>