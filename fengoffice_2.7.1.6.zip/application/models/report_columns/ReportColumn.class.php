<?php

  /**
  * ReportColumn class
  *
  * 
  */
  class ReportColumn extends BaseReportColumn {
      
    /**
    * Construct the object
    *
    * @param void
    * @return null
    */
    function __construct() {
      parent::__construct();
    } // __construct
    
   
  } // ReportColumn

?>