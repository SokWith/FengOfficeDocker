<?php

/**
 * ContactDimensionPermission class
 *
 * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
 */
class ContactDimensionPermission extends BaseContactDimensionPermission {
	

} // ContactDimensionPermission

?>