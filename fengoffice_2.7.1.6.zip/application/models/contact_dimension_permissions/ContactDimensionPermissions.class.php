<?php

  /**
  * ContactDimensionPermissions
  *
  * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
  */
  class ContactDimensionPermissions extends BaseContactDimensionPermissions {
    
      
  } // ContactDimensionPermissions 

?>