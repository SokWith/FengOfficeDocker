<?php

  /**
  * ReportCondition class
  *
  * 
  */
  class ReportCondition extends BaseReportCondition {
      
    /**
    * Construct the object
    *
    * @param void
    * @return null
    */
    function __construct() {
      parent::__construct();
    } // __construct
    
   
  } // ReportCondition

?>