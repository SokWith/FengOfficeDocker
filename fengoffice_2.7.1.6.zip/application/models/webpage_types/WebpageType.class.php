<?php

  /**
  * WebpageType class
  * 
  * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
  */
  class WebpageType extends BaseWebpageType {
  
        
  } // WebpageType 

?>