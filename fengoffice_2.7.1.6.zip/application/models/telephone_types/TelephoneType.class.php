<?php

  /**
  * TelephoneType class
  * 
  * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
  */
  class TelephoneType extends BaseTelephoneType {
  
        
  } // TelephoneType 

?>