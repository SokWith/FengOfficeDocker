<?php 
/**
 * 
 * Enter description here ...
 *
 */
class ContactWidget extends  BaseContactWidget {
	
}