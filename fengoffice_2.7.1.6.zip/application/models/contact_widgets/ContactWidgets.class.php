<?php 
/**
 * 
 * Enter description here ...
 *
 */
class ContactWidgets extends BaseContactWidgets {


	
}