<?php

/**
 * DimensionObjectTypeHierarchy class
 *
 * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
 */
class DimensionObjectTypeHierarchy extends BaseDimensionObjectTypeHierarchy {
	

} // DimensionObjectTypeHierarchy

?>