<?php

  /**
  * PermissionContexts
  *
  * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
  */
  class PermissionContexts extends BasePermissionContexts {
    
    
    
  } // PermissionContexts 

?>