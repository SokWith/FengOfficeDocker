<?php

/**
 * MemberPropertyMember class
 *
 * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
 */
class MemberPropertyMember extends BaseMemberPropertyMember {
	

} // MemberPropertyMember

?>