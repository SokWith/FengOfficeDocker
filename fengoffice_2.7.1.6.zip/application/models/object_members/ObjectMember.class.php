<?php

/**
 * ObjectMember class
 *
 * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
 */
class ObjectMember extends BaseObjectMember {
	

} // ObjectMember

?>