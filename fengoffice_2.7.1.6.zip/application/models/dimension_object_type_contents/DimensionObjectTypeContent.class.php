<?php

/**
 * DimensionObjectTypeContent class
 *
 * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
 */
class DimensionObjectTypeContent extends BaseDimensionObjectTypeContent {
	

} // DimensionObjectTypeContent

?>