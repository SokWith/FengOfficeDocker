<?php

/**
 * CustomPropertyValue class
 */
class CustomPropertyByCoType extends BaseCustomPropertyByCoType {


} // ObjectPropertyValue

?>