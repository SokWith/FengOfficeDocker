<?php

/**
 * TabPanelPermission class
 *
 * @author Alvaro Torterola <alvaro.torterola@fengoffice.com>
 */
class TabPanelPermission extends BaseTabPanelPermission {
	

} // TabPanelPermission

?>