<?php

/**
 * ProjectWebpages, generated on Wed, 15 Mar 2006 22:57:46 +0100 by
 * DataObject generation tool
 *
 * @author Feng Office Dev Team <contact@opengoo.org>
 */
class ProjectWebpages extends BaseProjectWebpages {

	public function __construct() {
		parent::__construct ();
		$this->object_type_name = 'weblink';
	}
	
} // ProjectWebpages

?>