<?php

/**
 * DimensionMemberRestrictionDefinition class
 *
 * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
 */
class DimensionMemberRestrictionDefinition extends BaseDimensionMemberRestrictionDefinition {
	

} // DimensionMemberRestrictionDefinition

?>