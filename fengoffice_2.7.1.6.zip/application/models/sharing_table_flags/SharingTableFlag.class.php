<?php

class SharingTableFlag extends BaseSharingTableFlag {


}