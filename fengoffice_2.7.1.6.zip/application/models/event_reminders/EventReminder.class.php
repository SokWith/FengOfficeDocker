<?php

  /**
  * EventReminder class
  *
  * @author Marcos Saiz <marcos.saiz@gmail.com>
  */
  class EventReminder extends BaseEventReminder {
  
  } // EventReminder 

?>