<?php

/**
 * MemberRestriction class
 *
 * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
 */
class MemberRestriction extends BaseMemberRestriction {
	

} // MemberRestriction

?>