<?php
/**
 * ExternalCalendarUser
 * Generado el 22/2/2012
 * 
 */
class ExternalCalendarUser extends BaseExternalCalendarUser {
    
}
?>