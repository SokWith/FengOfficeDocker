<?php

/**
 * AdministrationLog class
 * Generated on Tue, 07 Mar 2006 12:19:49 +0100 by DataObject generation tool
 *
 * @author Ilija Studen <ilija.studen@gmail.com>
 */
class AdministrationLog extends BaseAdministrationLog {

} // AdministrationLog

?>