<?php

/**
 * RoleObjectTypePermission class
 *
 * @author Alvaro Torterola <alvaro.torterola@fengoffice.com>
 */
class RoleObjectTypePermission extends BaseRoleObjectTypePermission {
	

} // RoleObjectTypePermission

?>