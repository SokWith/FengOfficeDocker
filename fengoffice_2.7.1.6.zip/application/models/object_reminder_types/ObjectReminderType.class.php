<?php

/**
 * ObjectReminderType class
 * Generated on Mon, 29 May 2006 03:51:15 +0200 by DataObject generation tool
 *
 * @author Ignacio de Soto <ignacio.desoto@fengoffice.com>
 */
class ObjectReminderType extends BaseObjectReminderType {

} // ObjectReminderType

?>