<?php

/**
 * ObjectReminderTypes
 *
 * @author Ignacio de Soto <ignacio.desoto@fengoffice.com>
 */
class ObjectReminderTypes extends BaseObjectReminderTypes {

} // ObjectReminderTypes

?>