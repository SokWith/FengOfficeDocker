<?php

  /**
  * AddressType class
  * 
  * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
  */
  class AddressType extends BaseAddressType {
  
        
  } // AddressType 

?>