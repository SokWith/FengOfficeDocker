<?php

/**
 * TabPanel class
 *
 * @author Alvaro Torterola <alvaro.torterola@fengoffice.com>
 */
class TabPanel extends BaseTabPanel {
	

} // TabPanel

?>