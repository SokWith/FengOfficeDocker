<?php

/**
 *  TemplateObjectProperty class
 *
 * @author Pablo Kamil
 */
class TemplateObjectProperty extends BaseTemplateObjectProperty {

	/**
    * Construct the object
    *
    * @param void
    * @return null
    */
    function __construct() {
      parent::__construct();
    } // __construct
    

} // TemplateObjectProperty

?>