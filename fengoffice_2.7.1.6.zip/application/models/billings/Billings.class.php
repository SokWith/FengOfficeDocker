<?php

  /**
  * Billings
  *
  * @author Diego Castiglioni <diego.castiglioni@fengoffice.com>
  */
  class Billings extends BaseBillings {
  	
  
	
  } // Billings 
  
?>