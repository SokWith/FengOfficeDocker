<?php

class SharingTable extends BaseSharingTable {


}