<?php
return '1';